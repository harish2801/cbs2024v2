import "./WelcomeForm.css";
import React,{useState }from 'react';
import TextField from '@mui/material/TextField';
import Table from '@mui/material/Table';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';
import logo from '../Assets/logo.png';
import { useNavigate } from 'react-router-dom';
const WelcomeForm = () => {
    const navigate = useNavigate();
    const [fAddr, setFAddr]=useState('Welcome to Ding Dong Courier. We are Happy to Serve for you.');
    const [fMobno, setFMobno]=useState();
    const handleHome = () => {
        navigate('/'); // Navigate to the About page
      };
    const handleSendMessage = async()=>{

        const number = fMobno;
        const type = "media";
        const message = fAddr;
        const mediaurl ="https://media.tenor.com/ONEFPGOqnJ8AAAAi/durstexpress-ding-dong.gif";
        const instanceId = "6676CCA1D216D";
        const accessToken = "666f1367878c0";
        try{
        const url = `https://web.betablaster.in/api/send?number=91${number}&type=${type}&message=${message}&media_url=${mediaurl}&instance_id=${instanceId}&access_token=${accessToken}`;
              // link.click();
              const response = await fetch(url);
              console.log(response);
              if (!response.ok) {
                throw new Error('Network response was not ok');
              }
          
              const result = await response.json();
              console.log('Success:', result);
             
            } catch (error) {
              console.error('Error:', error);
            }
           
            
          };
    return (

    <div className='container'>
     <Table sx={{ minWidth: 1200 }} aria-label="spanning table">
          <TableRow>
            <TableCell align="center" >
            <div className="logo">
                 <img src={logo} width="350" height="70" alt="rkay" />
             </div>
            </TableCell>
            </TableRow>
            <TableRow>
            <TableCell align="center" >
            <TextField id="FMobNo" name="FMobNo"className='form-control' required value={fMobno}  label="From Mobile Number" variant="standard" onChange={(e)=>setFMobno(e.target.value.toUpperCase())}/>
            </TableCell>
            </TableRow>
            <TableRow>
            <TableCell align="center" >
            <TextField 
            id="FAddr"
            name="FAddr"
            className='form-control' 
            InputProps={{
              style: { whiteSpace: 'pre-wrap', overflowWrap: 'break-word' },
            }} 
            required 
            value={fAddr} 
            onChange={(e)=>setFAddr(e.target.value)} 
            label="Message" 
            variant="standard" 
            multiline
            fullWidth
            maxRows={5}/>
            </TableCell>
            </TableRow>
            <TableRow>
            <TableCell align="center" >
            <Button  variant="contained" type="" onClick={handleSendMessage}>Send Message</Button>
            </TableCell>
            </TableRow>
            <TableRow>
            <TableCell align="center" >
            <Button  variant="contained" type="" onClick={handleHome}>Back to Home</Button>
            </TableCell>
            </TableRow>
            </Table>
    </div>
  )
}

export default WelcomeForm        