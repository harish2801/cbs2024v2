import "./BookingForm.css"
import React,{useState,useEffect,useRef,useCallback }from 'react';
import TextField from '@mui/material/TextField';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import logo from '../Assets/logo.png';
import courier1 from '../Assets/ST Courier.jpg';
import delhi from '../Assets/delhivery.png';
import aramex from '../Assets/aramex.png';
import bluedart from '../Assets/bluedart.png';
import dhl from '../Assets/dhl.png';
import dtdc from '../Assets/dtdc.png';
import franch from '../Assets/franch.png';
import trackon from '../Assets/trackon.png';
import movin from '../Assets/movin.jpeg';
import professional from '../Assets/professional.png';
import ecom from '../Assets/ecom.jpeg';
import xpressbees from '../Assets/xpressbees.jpeg';
import fedex from '../Assets/fedex.jpeg';
import ekart from '../Assets/ekart.jpeg';
import amazon from '../Assets/amazon.jpeg';
import welcome from '../Assets/welcome.jpg';
import { useNavigate } from 'react-router-dom';
import Table from '@mui/material/Table';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Barcode from "react-barcode";
import Button from '@mui/material/Button';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const BookingForm = ({courier,cname,websyt}) => {
  const navigate = useNavigate();
  const divRef = useRef();
    const [value, setValue]=useState("0");
   //const [dob, setDob]=useState();
    const [fMobno, setFMobno]=useState();
    const [fName, setFName]=useState();
    const [fAddr, setFAddr]=useState();
    const [fPincode, setFPincode]=useState("6000001");
    const [fEmail, setFEmail]=useState();
    const [tMobno, setTMobno]=useState();
    const [tName, setTName]=useState();
    const [tAddr, setTAddr]=useState();
    const [tPincode, setTPincode]=useState();
    const [tEmail, setTEmail]=useState();
    const [weight, setWeight]=useState('0.250');
    const [qty, setqty]=useState('1');
    const [type, setType]=useState('DOX');
    const [amount, setAmount]=useState();
    const [inputValue, setInputValue] = useState('');
    const cDate = new Date();

// Format: MM/DD/YYYY
    const fDate = `${cDate.getDate()}/${cDate.getMonth() + 1}/${cDate.getFullYear()}`;
    const delhivery = () => {
      navigate('/delhi'); // Navigate to the About page
    };
    const stcourier = () => {
        navigate('/'); // Navigate to the About page
      };
      const aramexc = () => {
        navigate('/aramex'); // Navigate to the About page
      };
      const bluec = () => {
        navigate('/blue'); // Navigate to the About page
      };
      const dhlc = () => {
        navigate('/dhl'); // Navigate to the About page
      };
      const dtdcc = () => {
        navigate('/dtdc'); // Navigate to the About page
      };
      const franchc = () => {
        navigate('/franch'); // Navigate to the About page
      };
      const trackc = () => {
        navigate('/track'); // Navigate to the About page
      };
      const profess = () => {
        navigate('/profess'); // Navigate to the About page
      };
      const ecomc = () => {
        navigate('/ecom'); // Navigate to the About page
      };
      const amazonc = () => {
        navigate('/amazon'); // Navigate to the About page
      };
      const ekartc = () => {
        navigate('/ekart'); // Navigate to the About page
      };
      const movinc = () => {
        navigate('/movin'); // Navigate to the About page
      };
      const fedexc = () => {
        navigate('/fedex'); // Navigate to the About page
      };
      const expressc = () => {
        navigate('/express'); // Navigate to the About page
      };
      const welcomec=()=>{
        navigate('/welcome');
      }
    const setValueBar=(e)=>{
        setValue(e.target.value);
    }
  
    const setFMobnoSearch=(e)=>{
      const newValue = e.target.value;
     
      setFMobno(newValue);

      //handleBlur();
  }
 
  const setTMobnoSearch=(e)=>{
    const newValue = e.target.value;
   
    setTMobno(newValue);

    //handleBlur();
}
const handleTlur = useCallback(async () => {
  if (!tMobno) return;
  try {
    const url = new URL('https://script.google.com/macros/s/AKfycbyy1s0F9OQWOskozRw4UcmTfvge__0UgATsATmbxcLNWR_9oQEYGmGkL68MG-c9fcH_/exec');
    url.searchParams.append('TMobNo', tMobno);

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const result = await response.json();
    console.log(result[0].Femail);
    const fetchedValue = 'Fetched data';

    setInputValue(fetchedValue);
   
    setTMobno(result[0].TMobNo || "");
    setTName(result[0].TName || "");
    setTAddr(result[0].TAddr || "");
    setTPincode(result[0].TPincode || "");
    setTEmail(result[0].Temail || "");
   
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}, [tMobno]);
  const handleBlur = useCallback(async () => {
    if (!fMobno) return;
    try {
      const url = new URL('https://script.google.com/macros/s/AKfycbyy1s0F9OQWOskozRw4UcmTfvge__0UgATsATmbxcLNWR_9oQEYGmGkL68MG-c9fcH_/exec');
      url.searchParams.append('FMobNo', fMobno);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const result = await response.json();
      console.log(result[0].Femail);
      const fetchedValue = 'Fetched data';

      setInputValue(fetchedValue);
      setFName(result[0].FName || "");
      setFAddr(result[0].FAddr || "");
      setFPincode(result[0].FPincode || "");
      setFEmail(result[0].Femail || "");
      setTMobno(result[0].TMobNo || "");
      setTName(result[0].TName || "");
      setTAddr(result[0].TAddr || "");
      setTPincode(result[0].TPincode || "");
      setTEmail(result[0].Temail || "");
      setWeight(result[0].Weight || "");
      setqty(result[0].Qty || "");
      setType(result[0].Type || "");
      setAmount(result[0].Amount || "");
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }, [fMobno]);

  const handleAwbNoBlur = useCallback(async () => {
    if (!value) return;
    try {
      const url = new URL('https://script.google.com/macros/s/AKfycbyy1s0F9OQWOskozRw4UcmTfvge__0UgATsATmbxcLNWR_9oQEYGmGkL68MG-c9fcH_/exec');
      url.searchParams.append('AwbNo', value);

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const result = await response.json();
      console.log(result[0].Femail);
      const fetchedValue = 'Fetched data';
      setInputValue(fetchedValue);
      setFMobno(result[0].FMobNo || "");
      setFName(result[0].FName || "");
      setFAddr(result[0].FAddr || "");
      setFPincode(result[0].FPincode || "");
      setFEmail(result[0].Femail || "");
      setTMobno(result[0].TMobNo || "");
      setTName(result[0].TName || "");
      setTAddr(result[0].TAddr || "");
      setTPincode(result[0].TPincode || "");
      setTEmail(result[0].Temail || "");
      setWeight(result[0].Weight || "");
      setqty(result[0].Qty || "");
      setType(result[0].Type || "");
      setAmount(result[0].Amount || "");
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }, [value]);

  useEffect(() => {
    handleBlur();
  }, [handleBlur]);

  useEffect(() => {
    handleAwbNoBlur();
  }, [handleAwbNoBlur]);
  useEffect(() => {
    handleTlur();
  }, [handleTlur]);


  const handleScreenshot = async () => {
   // handleSendMessage();
    if (divRef.current) {
      const canvas = await html2canvas(divRef.current);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = canvas.height * imgWidth / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save('download.pdf');
    }
}
    
const handleSendMessage = async()=>{
const number = fMobno;
const number1 = tMobno;
const type = "media";
const message = "Thank You for using Dingdong Courier. %0A Sender: "+fName+"%0A Your Awb No: "+value+"%0A Send Via:" + websyt+ " %0A Dated: "+fDate+" %0A To: "+tName+"%0A Have a Nice Day....";
const instanceId = "6671245DE3176";
const accessToken = "666f1367878c0";
try{
const url = `https://web.betablaster.in/api/send?number=91${number}&type=${type}&message=${message}&instance_id=${instanceId}&access_token=${accessToken}`;
      // link.click();
      const response = await fetch(url);
      console.log(response);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
  
      const result = await response.json();
      console.log('Success:', result);
     
    } catch (error) {
      console.error('Error:', error);
    }
    try{
      const url1 = `https://web.betablaster.in/api/send?number=91${number1}&type=${type}&message=${message}&instance_id=${instanceId}&access_token=${accessToken}`;
            // link.click();
            const response1 = await fetch(url1);
            console.log(response1);
            if (!response1.ok) {
              throw new Error('Network response was not ok');
            }
        
            const result1 = await response1.json();
            console.log('Success:', result1);
           
          } catch (error) {
            console.error('Error:', error);
          }
    
  };
  const handleThreeScreen = async () => {
    if (divRef.current) {
      const canvas = await html2canvas(divRef.current);
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      //const imgHeight = canvas.height * imgWidth / canvas.width;
      
      const segmentHeight = pageHeight / 3; // Height of each image segment

    for (let i = 0; i < 3; i++) {
      const position = i * segmentHeight;
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, segmentHeight);
    }

      pdf.save('download.pdf');
    }
    
  };
  
  const clearScreen = async()=>{
        
        setFMobno("");    
        setFName("");
        setFAddr("");
        setFPincode("600001");
        setFEmail("");
        setTMobno("");
        setTName("");
        setTAddr("");
        setTPincode("");
        setTEmail("");
        setWeight("0.250");
        setqty("1");
        setType("");
        setAmount("");
        setValue("");
       
  }
    const handleSubmit= async(e)=>{
        
          
      const currentDate = new Date();

// Format: MM/DD/YYYY
    const formattedDate = `${currentDate.getDate()}/${currentDate.getMonth() + 1}/${currentDate.getFullYear()}`;

      e.preventDefault();
        const formData = new FormData();
        formData.append('Dob', formattedDate);
        formData.append('AwbNo', value);
        formData.append('Weight', weight);
        formData.append('Qty', qty);
        formData.append('Type', type);
        formData.append('Amount', amount);
        formData.append('FMobNo', fMobno);
        formData.append('FName', fName);
        formData.append('FAddr', fAddr);
        formData.append('FPincode', "600001");
        formData.append('Femail', fEmail);
        formData.append('TMobNo', tMobno);
        formData.append('TName', tName);
        formData.append('TAddr', tAddr);
        formData.append('TPincode', tPincode);
        formData.append('Temail', tEmail);
        formData.append('Courier', cname);
        
       
        console.log(formData); 
        try {
          const response = await fetch('https://script.google.com/macros/s/AKfycbyy1s0F9OQWOskozRw4UcmTfvge__0UgATsATmbxcLNWR_9oQEYGmGkL68MG-c9fcH_/exec', {
            method: 'POST',
            body: formData
          });
    
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
      
          const result = await response.json();
          console.log('Success:', result);
         
        } catch (error) {
          console.error('Error:', error);
        }
        handleSendMessage();
        alert("Shipment Booked");
       
        clearScreen();
    
    }
    
    
  return (

<div className='container'>
   
<form autoComplete="off" className='form-group'
      onSubmit={handleSubmit}>
     <div ref={divRef}>
         <Table sx={{ minWidth: 1200 }} aria-label="spanning table">
          <TableRow>
            <TableCell align="center" >
            <div className="logo">
                 <img src={logo} width="350" height="70" alt="rkay" />
             </div>
            </TableCell>
            <TableCell align="center"  >
            <LocalizationProvider dateAdapter={AdapterDayjs} >
                <DatePicker name="Dob" id="Dob"  defaultValue={dayjs(new Date())} className='form-control' required/>
    </LocalizationProvider>
            </TableCell>
            
            <TableCell align="center" >
            <div><Barcode width="2" height="50" value={value}/></div>
           </TableCell>
           <TableCell align="center" >
            <div className="logo">
                 <img src={courier} width="250" height="70" alt="rkay" />
             </div>
            </TableCell> 
            </TableRow>
            <TableRow >
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="FMobNo" name="FMobNo"className='form-control' required value={fMobno}  label="From Mobile Number" variant="standard" onChange={setFMobnoSearch}/>
            </TableCell> 
            <TableCell sx={{ verticalAlign: 'top' }}  >
            <TextField id="FName"  name="FName"className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={fName} onChange={(e)=>setFName(e.target.value.toUpperCase())} label="From Name" variant="standard" />
            </TableCell> 
             
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField 
            id="FAddr"
            name="FAddr"
            className='form-control' 
            InputLabelProps={{shrink: !!inputValue || inputValue === 0}}
            InputProps={{
              style: { whiteSpace: 'pre-wrap', overflowWrap: 'break-word' },
            }} 
            required 
            value={fAddr} 
            onChange={(e)=>setFAddr(e.target.value.toUpperCase())} 
            label="From Address" 
            variant="standard" 
            multiline
            fullWidth
            maxRows={5}/>
            </TableCell>
            <TableCell sx={{ verticalAlign: 'top' }} >
              <div hidden>
            <TextField id="FPincode" name="FPincode"  className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={fPincode} onChange={(e)=>setFPincode(e.target.value)} label="From Pincode" variant="standard" />
            </div> <br />
            <TextField id="Femail" name="Femail" className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}}  value={fEmail} onChange={(e)=>setFEmail(e.target.value)} label="From EmailID" variant="standard" />
            
            </TableCell> 
             </TableRow> 
            
             <TableRow>
             <TableCell sx={{ verticalAlign: 'top' }}  >
            <TextField id="TMobNo" name="TMobNo"className='form-control'InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={tMobno} onChange={setTMobnoSearch} label="To Mobile Number" variant="standard" />
            </TableCell> 
            
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="TName" name="TName"  className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={tName} onChange={(e)=>setTName(e.target.value.toUpperCase())} label="To Name" variant="standard" />
            </TableCell> 
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="TAddr" name="TAddr" InputProps={{
            style: { whiteSpace: 'pre-wrap', overflowWrap: 'break-word' },
          }} fullWidth className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={tAddr} onChange={(e)=>setTAddr(e.target.value.toUpperCase())} label="To Address" variant="standard" multiline
          maxRows={5} />
            </TableCell>

           
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="TPincode" name="TPincode" className='form-control'InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={tPincode} onChange={(e)=>setTPincode(e.target.value)} label="To Pincode" variant="standard" />
            <br />
            <TextField id="Temail" name="Temail" className='form-control'InputLabelProps={{shrink: !!inputValue || inputValue === 0}}  value={tEmail} onChange={(e)=>setTEmail(e.target.value)} label="To Email ID" variant="standard" />
            </TableCell> 
             </TableRow>
             
             <TableRow>
             <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="AwbNo"   name="AwbNo" className='form-control' required value={value}  label="Airway Bill No" variant="standard" onChange={setValueBar} />
            </TableCell>
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="Weight" name="Weight" className='form-control'InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={weight} onChange={(e)=>setWeight(e.target.value)} label="Weight" placeholder="0.250" variant="standard" />
            </TableCell> 
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="Qty" name="Qty" className='form-control'InputLabelProps={{shrink: !!inputValue || inputValue === 0}} required value={qty} onChange={(e)=>setqty(e.target.value)} label="Quantity" placeholder="1" variant="standard" />
            </TableCell> 
           
            <TableCell sx={{ verticalAlign: 'top' }} >
            <TextField id="Amount" name="Amount" className='form-control' InputLabelProps={{shrink: !!inputValue || inputValue === 0}}  value={amount} onChange={(e)=>setAmount(e.target.value)} label="Amount" placeholder="0.00" variant="standard" />
            </TableCell> 
             </TableRow>
            
            </Table>
           
            </div>
            
            <div className="submit">
            <Button  variant="contained" type="submit">Book Shipment</Button>
            </div>
           
           
    </form>
    
    <Table sx={{ minWidth: 1200 }} aria-label="spanning table">
              <TableRow>
             <TableCell sx={{ verticalAlign: 'top' }} >
            <Button  variant="contained" type="" onClick={handleScreenshot}>Print</Button>
            </TableCell> 
            <TableCell sx={{ verticalAlign: 'top' }} >
            <Button  variant="contained" type="" onClick={handleSendMessage}>WhatsApp</Button>
            </TableCell> 
            
            <TableCell sx={{ verticalAlign: 'top' }}align="center" >
            <Button  variant="contained" type="" onClick={handleThreeScreen}>3 Copies Print</Button>
            </TableCell>
            <TableCell sx={{ verticalAlign: 'top'}}align="right" >
            <Button  variant="contained" type="" onClick={clearScreen}>Clear</Button>
            </TableCell> 
             </TableRow>
            </Table>
            <Table sx={{ minWidth: 1200 }} aria-label="spanning table">
      <TableRow>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={stcourier}>
        <img src={courier1} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell> 
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={delhivery}>
        <img src={delhi} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined"onClick={aramexc}>
        <img src={aramex} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={bluec}>
        <img src={bluedart} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={dhlc}>
        <img src={dhl} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell> 
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={dtdcc}>
        <img src={dtdc} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={franchc}>
        <img src={franch} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={trackc}>
        <img src={trackon} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={profess}>
        <img src={professional} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell> 
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={amazonc}>
        <img src={amazon} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined"onClick={ekartc}>
        <img src={ekart} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={ecomc}>
        <img src={ecom} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={fedexc}>
        <img src={fedex} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell> 
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined" onClick={expressc}>
        <img src={xpressbees} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined"onClick={movinc}>
        <img src={movin} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
        <TableCell sx={{ verticalAlign: 'top' }} >
        <Button variant="outlined"onClick={welcomec}>
        <img src={welcome} width="200" height="50" alt="rkay" />
        </Button>
        </TableCell>
      </TableRow>
    </Table>
    <div className="awbPrint" ref={divRef} >
    <div >
 
    <Table sx={{ minWidth: 1000 }} aria-label="spanning table">
          <TableRow sx={{ border: '1px solid black' }}>
            <TableCell align="center" sx={{ border: '1px solid black' }}>
            <div className="logo">
                 <img src={logo} width="300" height="70" alt="rkay" />
             </div>
            </TableCell>
          
            
            <TableCell align="center"sx={{ border: '1px solid black' }}  >
            <div><Barcode width="3" height="50" value={value}/></div>
           </TableCell>
           <TableCell align="center"sx={{ border: '1px solid black' }} >
            <div className="logo">
                 <img src={courier} width="250" height="60" alt="rkay" />
             </div>
            </TableCell> 
            </TableRow>
            <TableRow sx={{ border: '1px solid black' }}>
              <TableCell sx={{ border: '1px solid black' }}>
                From
              </TableCell>
              <TableCell  sx={{ border: '1px solid black' }} >
                <span className="toName">To</span>
              </TableCell>
              <TableCell align="center" sx={{ border: '1px solid black' }} >
           Date: {fDate}
            </TableCell>
            </TableRow>
            <TableRow sx={{ border: '1px solid black' }}>
              <TableCell sx={{ border: '1px solid black', alignContent:"flex-start" }}>
              <span className="foName">
               {fName} <br />
              
               {fAddr}
               <br />
               {fMobno} <br />
               </span>
              </TableCell>
              <TableCell colSpan="2" sx={{ border: '1px solid black' }} >
                <span className="toName">
               {tName} <br />
               <div className="addr" style={{  whiteSpace: 'pre-wrap' }}>
               {tAddr}
               </div>
               Pincode: {tPincode} <br />
               Mobile No: {tMobno} <br />
               {tEmail}</span>
              </TableCell>
            </TableRow>
            <TableRow sx={{ border: '1px solid black' }}>
              <TableCell sx={{ border: '1px solid black' }}>
              <span className="toName">Weight {weight} </span>
               </TableCell>
              <TableCell  sx={{ border: '1px solid black' }} >
                <span className="toName">No of Pcs: {qty} </span>
              </TableCell>
              
              <TableCell  sx={{ border: '1px solid black' }} >
                <span className="toName">Amount: {amount} </span>
              </TableCell>
            </TableRow>
            </Table>
            
    </div>
    </div>
</div>
  )
}

export default BookingForm