import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BookingForm from './Components/BookingForm/BookingForm';
import WelcomeForm from './Components/WelcomeForm/WelcomeForm';
import courier from './Components/Assets/ST Courier.jpg';
import delhi from './Components/Assets/delhivery.png';
import aramex from './Components/Assets/aramex.png';
import bluedart from './Components/Assets/bluedart.png';
import dhl from './Components/Assets/dhl.png';
import dtdc from './Components/Assets/dtdc.png';
import franch from './Components/Assets/franch.png';
import trackon from './Components/Assets/trackon.png';
import movin from './Components/Assets/movin.jpeg';
import professional from './Components/Assets/professional.png';
import ecom from './Components/Assets/ecom.jpeg';
import xpressbees from './Components/Assets/xpressbees.jpeg';
import fedex from './Components/Assets/fedex.jpeg';
import ekart from './Components/Assets/ekart.jpeg';
import amazon from './Components/Assets/amazon.jpeg';

import './App.css';

function App() {
  return (
    <Router>
    <Routes>
      <Route path="/" element={<BookingForm courier={courier} cname="ST Courier" websyt="www.stcourier.com"/>} />
      <Route path="/delhi" element={<BookingForm courier={delhi} cname="Delhivery" websyt="www.delhivery.com"/>} />
      <Route path="/aramex" element={<BookingForm courier={aramex} cname="Aramex" websyt="www.aramex.com"/>} />
      <Route path="/blue" element={<BookingForm courier={bluedart} cname="BlueDart" websyt="www.bluedart.com"/>} />
      <Route path="/dhl" element={<BookingForm courier={dhl} cname="DHL" websyt="www.dhl.com"/>} />
      <Route path="/dtdc" element={<BookingForm courier={dtdc} cname="DTDC" websyt="www.dtdc.com"/>} />
      <Route path="/franch" element={<BookingForm courier={franch} cname="FranchExpress" websyt="www.franchexpress.com"/>} />
      <Route path="/track" element={<BookingForm courier={trackon} cname="TrackOn" websyt="www.trackon.com"/>} />
      <Route path="/profess" element={<BookingForm courier={professional} cname="Professional" websyt="www.tpcindia.com"/>} />
      <Route path="/amazon" element={<BookingForm courier={amazon} cname="Amazon" websyt="www.track.amazon.in"/>} />
      <Route path="/ekart" element={<BookingForm courier={ekart} cname="Ekart" websyt="www.ekartlogistics.com"/>} />
      <Route path="/ecom" element={<BookingForm courier={ecom} cname="ECOM" websyt="www.ecomexpress.in"/>} />
      <Route path="/fedex" element={<BookingForm courier={fedex} cname="Fedex" websyt="www.fedex.com"/>} />
      <Route path="/express" element={<BookingForm courier={xpressbees} cname="XpressBees" websyt="www.xpressbees.com"/>} />
      <Route path="/movin" element={<BookingForm courier={movin} cname="Movin" websyt="www.movin.in"/>} />
      <Route path='/welcome' element={<WelcomeForm/>}/>
    </Routes>
  </Router>
  );
}

export default App;
